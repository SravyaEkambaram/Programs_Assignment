﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nullable_example
{
    class Program
    {
        static void Main(string[] args)
        {
            int? num = null;
            if(num.HasValue)
            {
                Console.WriteLine("num= "+num.Value );
            }
            else
            {
                Console.WriteLine("num=null"+num);
            }
            // y is set to zero
            int y = num.GetValueOrDefault();
            // num.Value throws an InvalidOperationException if num.HasValue is false
            try
            {
                y = num.Value;
            }
            catch(System.InvalidOperationException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();

        }
    }
}
