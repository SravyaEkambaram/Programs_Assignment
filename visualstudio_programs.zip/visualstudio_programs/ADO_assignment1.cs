﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;


namespace ADO.net1
{
    class Program
    {

        //  static string conString = @"Server=INCHCMPC11363;Database=assignmentDatabase;Trusted_Connection=True;";
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder(@"Server=");
            Console.WriteLine("Please enter the server name");
            sb.Append(Console.ReadLine());
            sb.Append(";Database=");
            Console.WriteLine("Please enter the database name");
            sb.Append(Console.ReadLine());
            sb.Append(";Trusted_Connection=True;");
            Console.WriteLine(sb);

            string Confirm;
            do
            {
                Console.WriteLine("Welcome to the sql Services");
                Console.WriteLine("1. Insert \n2. Update\n3.Delete\n4.Display");
                int choice = GetInt("Enter the choice");
                switch (choice)
                {
                    case 1:
                        InsertData(sb);
                        break;
                    case 2:
                        //   updatedata();

                        break;
                    case 3:
                       // Display(sb);
                        DeleteData(sb);
                        break;
                    case 4:
                        Display(sb);
                        break;
                    default:
                        Console.WriteLine("Please choose a valid option");
                        break;
                }
                Console.WriteLine("Enter 'y' to continue");
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "Y");
        }

        private static void DeleteData(StringBuilder sb)
        {
            Console.WriteLine("Please enter the tablename and condition for the deletion operation");
            StringBuilder s = new StringBuilder(@"DELETE FRom ");
            s.Append(Console.ReadLine());
            s.Append("where region_id = ");
            s.Append(Console.ReadLine());
            Console.WriteLine(s);

            //string stringg = @"Delete from sectors where sector_id = 11";
            
             try
             {
                  using (SqlConnection con = new SqlConnection(sb.ToString()))
                 {
                        string selectString = @"SELECT * FROM EMPLOYEES";
                        DataSet ds = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                        SqlCommandBuilder scb = new SqlCommandBuilder(da);
                        da.Fill(ds);
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                             if ((int)dr["EmployeeID"] == 14)
                             dr.Delete();
                        }
                        da.Update(ds);
                 }
             }
             catch (Exception ex)
             {
                Console.WriteLine($"Exception thrown while deleting data: {ex.Message}");
             }
        }

        private static void InsertData(StringBuilder sb)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sb.ToString()))
                {
                    con.Open();
                    Console.WriteLine("values are inserted");
                    string selectString = @"SELECT * FROM Region";
                    using (SqlCommand cmd = new SqlCommand(selectString, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                        DataSet ds = new DataSet();
                        SqlCommandBuilder scb = new SqlCommandBuilder(da);
                        da.Fill(ds);
                        DataRow dr = ds.Tables[0].NewRow();
                        dr["RegionID"] = "6";
                        dr["RegionDescription"] = "Western";
                        DataTable dt = ds.Tables[0];
                        dt.Rows.Add(dr);
                        da.Update(ds);
                        
                            Console.WriteLine(dr["RegionID"]);
                            Console.WriteLine(dr["RegionDescription"]);
                        
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while updating data: {ex.Message}");
            }
        }
        private static void UpdateData(StringBuilder sb)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sb.ToString()))
                {
                    con.Open();
                    Console.WriteLine("values are inserted");
                    string selectString = @"SELECT * FROM Region";
                    using (SqlCommand cmd = new SqlCommand(selectString, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                        DataSet ds = new DataSet();
                        SqlCommandBuilder scb = new SqlCommandBuilder(da);
                        da.Fill(ds);
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            if ((int)dr["RegionID"] == 5)
                                dr["RegionDescription"] = "Foreign";
                        }
                        da.Update(ds);

                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            Console.WriteLine(dr["RegionID"]);
                            Console.WriteLine(dr["RegionDescription"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while inserting data: {ex.Message}");
            }
        }

        private static void Display(StringBuilder sb)
        {

            Console.WriteLine("Please enter the table to be selected");
            string cmdString = @"SELECT * FROM  " + Console.ReadLine();
            using (SqlConnection con = new SqlConnection(sb.ToString()))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    DataTable dt = new DataTable();
                    da.Fill(ds);

                    foreach (DataColumn dr in ds.Tables[0].Columns)
                    {
                       // Console.WriteLine("column names");
                        Console.WriteLine("{0,15}", dr.ColumnName);
                    }

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        Console.WriteLine(dr["RegionID"]);
                        Console.WriteLine(dr["RegionDescription"]);
                    }
                }
            }
         }
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                
                Console.WriteLine("The entered number is not in correct format please try again");
                
            }
            return val;
        }
    }
}