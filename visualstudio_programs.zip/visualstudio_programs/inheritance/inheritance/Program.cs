﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance
{
    class Program
    {
        class Base
        {            
            //public void setwidth(int b)
            //{
            //    width = b;
            //}
            //public void setheight(int h)
            //{
            //    height = h;
            //}
            public int width { get; set; }
            public  int height { get; set; }

        }
        class Derived : Base
        {
            
            public int getarea()
            {                              
                return width * height;
            }

        }
        class tester
        {
            static void Main(string[] args)
            {
                Derived d = new Derived { width = 6,height = 3 };
                //d.setwidth(2);
                //d.setheight(4);
                Console.WriteLine($"area of rect is {d.getarea()}");
                Console.ReadKey();
            }
        }
    }
}
