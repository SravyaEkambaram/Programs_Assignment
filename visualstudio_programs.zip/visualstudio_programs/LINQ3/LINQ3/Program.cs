﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ3
{
    class Program
    {
        //private static object lower;

        //public static object Upper { get; private set; }

        static void Main(string[] args)
        {
            string[] words = { "aPPle", "bAll", "woRLd" };
            var upperlowerwords=from w in words
                                select new{ Upper=w.ToUpper(), lower=w.ToLower()};
            foreach(var item in upperlowerwords)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
