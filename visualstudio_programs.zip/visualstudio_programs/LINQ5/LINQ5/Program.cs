﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ5
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "tom", "harry", "chutki" };
            IEnumerable<string>filterednames= names.Where( n => n.Length >= 4);
            foreach(string name in filterednames)
            {
                Console.WriteLine(name);
            }
            //names that contains letter
            IEnumerable<string> filterednames2 = names.Where(n => n.Contains("a"));
            foreach (string name in filterednames2)
            {
                Console.WriteLine(name);
            }
            Console.ReadKey();
        }
    }
}
