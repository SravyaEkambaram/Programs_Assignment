﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace anagrampalindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("enter choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        anagram();
                        break;
                    case 2:
                        palindrome();
                        break;

                }
            }

        }
        public static void anagram()
        {
            Console.Write("Enter first word:");
            string word1 = Console.ReadLine();
            Console.Write("Enter second word:");
            string word2 = Console.ReadLine();

            char[] ch1 = word1.ToCharArray();
            char[] ch2 = word2.ToCharArray();
            Array.Sort(ch1);
            Array.Sort(ch2);
            string NewWord1 = new string(ch1);
            string NewWord2 = new string(ch2);

            if (NewWord1 == NewWord2)
            {
                Console.WriteLine(" Words {0} and {1} are Anagrams", word1, word2);
            }
            else
            {
                Console.WriteLine(" Words {0} and {1} are not Anagrams", word1, word2);
            }

            Console.ReadLine();
        }


        public static void palindrome()
        {
            string s, revs = "";
            Console.WriteLine(" Enter string");
            s = Console.ReadLine();
            for (int i = s.Length - 1; i >= 0; i--) //String Reverse
            {
                revs += s[i].ToString();
            }
            if (revs == s) // Checking whether string is palindrome or not
            {
                Console.WriteLine("String is Palindrome ");
            }
            else
            {
                Console.WriteLine("String is not Palindrome");
            }
            Console.ReadKey();
        }
    }
}
   