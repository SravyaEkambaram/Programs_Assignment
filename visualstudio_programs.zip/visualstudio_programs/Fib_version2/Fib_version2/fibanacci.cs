﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fib_version2
{
    class Program
    {
        public static void fibSeriesEx3()
        {
            List<int> lst = new List<int> { 0, 1 };
            for (int i = 0; i <= 10; i++)
            {
                int num = lst.Skip(i).Sum();
                lst.Add(num);
            }

                foreach (int number in lst)
                Console.Write(number + " ");
                
        }
        
        static void Main(string[] args)
        {

            fibSeriesEx3();
            Console.ReadLine();
        }
    }
}
