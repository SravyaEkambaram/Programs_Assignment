﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generic
{
    class Program
    {
        static void Swap<T>(ref T lhs,ref T rhs)
        {
            T temp;
            temp = lhs;
            lhs = rhs;
            rhs = temp;
        }
        static void Main(string[] args)
        {
            int a=2, b=3;
            Console.WriteLine("before swapping");
            Console.WriteLine($"a is {a} and b is {b}");
            //call swap
            Swap<int>(ref a, ref b);
            Console.WriteLine("after swapping");
            Console.WriteLine($"a is {a} and b is {b}");
            Console.ReadKey();

        }
    }
}
