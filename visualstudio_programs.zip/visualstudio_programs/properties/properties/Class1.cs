﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace properties
{
    class Student
    {
        
            private string code = "N.A";
            private string name = "not known";
            private int age = 0;
        //private string v1;
        //private string v2;
        //private int v3;

        public Student(string code, string name, int age)
        {
            this.code = code;
            this.name = name;
            this.age = age;
        }

        // Declare a Code property of type string:
        public string Code
            {
                get
                {
                    return code;
                }
                set
                {
                    code = value;
                }
            }

            // Declare a Name property of type string:
            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    name = value;
                }
            }

            // Declare a Age property of type int:
            public int Age
            {
                get
                {
                    return age;
                }
                set
                {
                    age = value;
                }
            }
        public override string tostring()
        {
            return "code = " + code + ", name = " + name + ", age = " + age;
        }

    }

    }

