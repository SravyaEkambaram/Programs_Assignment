﻿using properties;
using System;
namespace tutorialspoint
{
    
    class ExampleDemo
    {
        public static void Main()
        {

            // Create a new Student object:
            Student s = new Student ( "001", "zara", 9 );

            // Setting code, name and the age of the student
            //s.Code = "001";
            //s.Name = "Zara";
            //s.Age = 9;
            Console.WriteLine("Student Info: {0}", s);

        
          Console.ReadKey();
        }
    }
}