﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 2, 4, 5, 6, 1 };
            var numsplusone = from n in nums
                              select n + 1;
            foreach(var item in numsplusone)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
