﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forforeachloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int[] num = { 2, 3, 4, 5 };
        }
    }
}
