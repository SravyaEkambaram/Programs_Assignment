﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    public class SavingsAccount : Account, ITransaction, IROI
    {
        int MaxwithdrawalAmount = 50000;
        int MaxDepositAmount = 50000;
        int minbal = 1000;
        public void OpenAccount()
        {
            Console.WriteLine("Enter the username");
            name = Console.ReadLine();
            Console.WriteLine("Enter the amount to be deposited");
            balance = Convert.ToInt32(Console.ReadLine());
            if (balance >= 1000)
            {
                
                Console.WriteLine("Savings Account is created successfully ");          
                Console.WriteLine("AccountNumber:{0}", acc_Number);
                Console.WriteLine("AccountName:{0}", name);
                Console.WriteLine("AccountBalance:{0}", balance);
            }
            else
            {                
                Console.WriteLine("Amount should be morethan 1000 to create an account");
                

            }

        }

        public void editAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;

                if (item.acc_Number == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the username to be modified");
                    item.name = Console.ReadLine();
               
                    Console.WriteLine("Your username is modified successfully");
                    Console.WriteLine("AccountName:{0}", item.name);
                
                    break;
                }
                else if (count == Program.salist.Count)
                {
                   
                    Console.WriteLine("Enter the valid account number");
                  
                }

            }

        }

        public void deposit()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;
                if (item.acc_Number == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the amount to be deposited");
                    int deposit = Convert.ToInt32(Console.ReadLine());
                    

                    try
                    {
                        if (deposit < MaxDepositAmount)
                        {
                            item.balance += deposit;                            
                            Console.WriteLine("Amount is deposited successfully");                      
                        }

                        else
                        {
                            throw new MaxDepositAmtException("You can not deposit ammount greater than 50000 ");
                        }
                    }
                    catch (MaxDepositAmtException e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    break;

                }
                else if (count == Program.salist.Count)
                {
                    Console.WriteLine("Please enter  valid account number");
                }
            }

        }
        public void withdrawl()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;
                if (item.acc_Number == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the amount to be Withdrawn");
                    int withdraw = Convert.ToInt32(Console.ReadLine());                   
                    try
                    {

                        if (withdraw < MaxwithdrawalAmount)
                        {

                            if ((item.balance - withdraw) > minbal)
                            {
                                item.balance -= withdraw;                             
                                Console.WriteLine("Amount is withdrawn successfully");
                                
                            }

                            else
                            {
                                throw new minBalException("Withdrawl Error! minBalance after withdrawal should be greater than 1000");
                            }

                        }

                        else
                        {
                            throw new MaxwithdrawalAmount("You can not withdraw amount greater than 50000");
                        }
                    }
                    catch (minBalException e)
                    {
                        Console.WriteLine(e.Message);
                  

                    }

                    catch (MaxwithdrawalAmount e)
                    {
                        Console.WriteLine(e.Message);                   
                    }
                    break;

                }
                else if (count == Program.salist.Count)
                {
                    
                    Console.WriteLine("Please entere the valid account number");
                    
                }
            }
        }
        public void checkBalance()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;
                if (item.acc_Number == numcheck)
                {
                    // Console.WriteLine("AccountBalance:{0}", item.balance);
                    GetRateOfInterest(numcheck);
                    break;
                }
                else if (count == Program.salist.Count)
                {
                    Console.WriteLine("Enter the valid account number");
                    
                }
            }
        }

        public void closeAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;
                try
                {
                    if (item.acc_Number == numcheck)
                    {
                        if (item.balance == 0)
                        {
                            Program.salist.Remove(item);
                        }
                        else
                        {
                            throw new AccountCloseException((" To close the Account the balance should be zero"));
                        }
                    }
                    else if (count == Program.salist.Count)
                    {
                        Console.WriteLine("Enter the valid account number");
                        
                    }
                }
                catch (AccountCloseException e)
                {
                    
                    Console.WriteLine(e.Message);
                    
                }
            }
        }
        public void getAccountDetails()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.salist)
            {
                count++;
                if (item.acc_Number == numcheck)
                {
                    Console.WriteLine("AccountNumber:{0}", item.acc_Number);
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("AccountBalance:{0}", item.balance);
                    break;
                }
                else if (count == Program.salist.Count)
                {
                    
                    Console.WriteLine("Enter the valid account number");
                    
                }
            }
        }
        public void transferAmount()
        {
            long fromaccount;
            long toaccount;
            Console.WriteLine("Enter the From account number");
            fromaccount = Convert.ToInt64(Console.ReadLine());
            int count = 0; int count1 = 0;
            foreach (var item in Program.salist)
            {
                count++;
                if (item.acc_Number == fromaccount)
                {
                    Console.WriteLine("Enter To account number");
                    toaccount = Convert.ToInt64(Console.ReadLine());


                    for (int i = 0; i < Program.salist.Count; i++)
                    {
                        count1++;
                        if (Program.salist[i].acc_Number == toaccount)
                        {

                            Console.WriteLine("Enter the ammount to be transfered");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if (fromaccount != toaccount)
                            {
                                if (item.balance > amount + minbal)
                                {
                                    item.balance = item.balance - amount;
                                    Program.salist[i].balance = Program.salist[i].balance + amount;
                                    Console.WriteLine("Balance is transferred successfully");
                                    Console.WriteLine($"The Available balance in the {Program.salist[i].acc_Number} is {Program.salist[i].balance }");
                                }
                                else
                                {
                                    Console.WriteLine("Insufficient balance to transfer");
                                }

                            }
                            else
                            {
                                Console.WriteLine("Transfer can be done between two different accounts");
                            }
                            break;

                        }
                        else if (count1 == Program.salist.Count)
                        {
                            Console.WriteLine("Please enter the valid account number");
                        }

                    }
                    break;
                }
                else if (count == Program.salist.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }
            }
        }

        public void GetRateOfInterest(long numcheck)
        {
            double simpleinterest = 0;
            foreach (var item in Program.salist)
            {
                if (item.acc_Number == numcheck)
                {
                    simpleinterest = item.balance * 0.04 * 1;
                    item.balance = item.balance + (int)simpleinterest;
                    Console.WriteLine($"The Available balance in {item.acc_Number} is {item.balance}");
                }
            }
        }
    }
}