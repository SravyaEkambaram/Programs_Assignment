﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorial
{
    class Program
    {
        public static void Main(String[] args)
        {

                int count, num, fact = 1;
                Console.WriteLine("enter a number:");
                num = int.Parse(Console.ReadLine());
                if (num < 0)
                {
                    Console.WriteLine("entered number is a negative number");
                }
                else
                {
                for (count = 1; count <= num; count++)
                {
                    fact = fact * count;
                    Console.WriteLine($"factorial is {count} {fact}");
                    
                }
                }
            Console.ReadKey();
        }

    }
}

