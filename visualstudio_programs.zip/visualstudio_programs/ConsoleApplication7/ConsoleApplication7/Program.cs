﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    

    class Test
    {
        static int Sum(params int[] ints)
        {
            int sum = 0;
            for (int i = 0; i < ints.Length; i++)
                sum += ints[i]; // Increase sum by ints[i]
            return sum;
        }
        void Foo(int x , int y = 0) { Console.WriteLine(x + ", " + y); }
        void Test1()
        {
            Foo(1); // 1, 0
        }
        static void Main()
        {
            int total = Sum(1, 2, 3, 4);
            Console.WriteLine(total); // 10
            Console.ReadKey();
        }
       
    }
 }


