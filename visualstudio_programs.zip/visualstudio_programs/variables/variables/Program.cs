﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variables
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstname="sravya";
            string lastname = "Ekambaram";
            
            Console.Write(firstname);
            Console.WriteLine(lastname);
            Console.ReadKey();

        }
     }
}

