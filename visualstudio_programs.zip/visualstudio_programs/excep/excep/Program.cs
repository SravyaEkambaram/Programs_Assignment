﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace excep
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Your age:");
            try
            {
               int age = Int32.Parse(Console.ReadLine());
            }
            catch (FormatException e)
            {
               
                Console.WriteLine("You have entered non-numeric characters");
            }
        }
    }
}
