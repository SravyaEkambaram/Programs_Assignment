﻿using FurnitureDealers1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFashionFurniture
{  
    class Program
    {
        static void Main(string[] args)
        {
            char ch;
            do
            {
                Model add = new Model();
                Console.WriteLine("My Fashion Furniture");
                Console.WriteLine("\n1: Add Model\n2: Delete Model\n3: Display all Models\n4: Price modificaton\n5: Models with  price Range\n6: Price of a model\n7: Check Availability\n8: Model with lowest price\nEnter Your Choice:");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        add.add_model();
                        break;
                    case 2:
                        add.delete_model();
                        break;
                    case 3:
                        add.display_all_models();
                        break;
                    case 4:
                        add.modify_price();
                        break;
                    case 5:
                        add.modelsln_Aprice_range();
                        break;
                    case 6:
                        add.a_model();
                        break;
                    case 7:
                        add.check_avl();
                        break;
                    case 8:
                        add.lowest_priced_model();
                        break;
                    default:
                        Console.WriteLine("WRONG SELECTION. SELECT ONLY 1 TO 7 ONLY");
                        break;
                }
                Console.WriteLine("To continue select Y or N");
                ch = Convert.ToChar(Console.ReadLine());
            } while ((ch == 'y') || (ch == 'Y'));
        }
    }
}


