﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ6
{
    class Program
    {
        static void Main(string[] args)
        {
            //chaining query operators
            string[] names = { "jack", "jill", "bheem", "harry" };
            IEnumerable<string> query = names.Where(n => n.Contains("a"))
                                           .OrderBy(n => n.Length)
                                           .Select(n => n.ToUpper());
            foreach(var n in query)
            {
                Console.WriteLine(n);
            }
            Console.ReadKey();
        }
    }
}
