﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorial_version2
{
    class Program
    {
        static void Main(string[] args)
        {

            int input = Convert.ToInt32(Console.ReadLine());
            int fact = 1;

            //computation
            Enumerable
                .Range(1, input)
                .ToList()
                .ForEach(i => fact *= i);

            //display the result
            Console.WriteLine("Factorial of {0} is {1}", input, fact);
            Console.ReadKey();
        }
    }
}
