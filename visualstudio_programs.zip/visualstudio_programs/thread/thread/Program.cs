﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace thread
{
    class Program
    {
        private static bool isThreadStop;

        static void Main(string[] args)
        {
            Console.WriteLine("main method starts");
            Thread th = new Thread(new ThreadStart(longmethod));
            th.Start();
            for(int i=0;i<10;i++)
            {
                Console.WriteLine($"inside main method {i}");
                Thread.Sleep(3000);
                if(i==3)
                {
                    isThreadStop = true;
                    //th.abort();
                }
            }
            Console.WriteLine("main method ended");
            Console.ReadLine();
        }
        static void longmethod()
        {
            try
            { 
              Console.WriteLine("long method starts");
              for (int i = 0; i < 10; i++)
              {
                    if(!isThreadStop)
                    {
                        Console.WriteLine($"[Debug] isThreadStop");
                        
                    
                       Console.WriteLine($"inside long method {i}");
                       Thread.Sleep(3000);
                     }
                    else
                        break;
               }
            }
            catch(ThreadAbortException ex)
            {
                Console.WriteLine($"exception due to {ex.Message}");
            }
            Console.WriteLine("Long method ended...");
}
    }
