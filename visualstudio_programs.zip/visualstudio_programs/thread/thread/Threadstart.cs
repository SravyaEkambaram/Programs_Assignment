﻿using System;

namespace thread
{
    internal class threadstart
    {
        private object longmethod;

        public threadstart(Action longmethod)
        {
            this.longmethod = longmethod;
        }

        public threadstart(object longmethod)
        {
            this.longmethod = longmethod;
        }
    }
}