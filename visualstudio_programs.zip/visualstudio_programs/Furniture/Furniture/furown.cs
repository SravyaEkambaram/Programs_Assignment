﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureDealer
{
    class Model:Furniture
    {
        public int id;
        public string model;
        public double price;
        public Boolean instock;
        public override string ToString()
        {

        }
        public void add_model()
        {
            Console.WriteLine("Enter the new model");
            string model =Console.ReadLine();
            Console.WriteLine("Enter the amount to be deposited");
            balance = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.mlist)
            {
                count++;
                if (item.model == )
                {
                    // Console.WriteLine("AccountBalance:{0}", item.balance);
                    GetRateOfInterest(numcheck);
                    break;
                }
                else if (count == Program.salist.Count)
                {
                   
                    Console.WriteLine("Enter the valid account number");
                    
                }
            }

        }
        public void delete_model()
        {

        }
        public display_allmodels()
        {
            Console.WriteLine("The available models are:");
        }
        public modify_price()
        {

        }
        public lowest_priced_model()
        {

        }
        public modelsIn_Aprice_range()
        {

        }
        public display_1model()
        {

        }
        public check_availability()
        {

        }



    }
}
