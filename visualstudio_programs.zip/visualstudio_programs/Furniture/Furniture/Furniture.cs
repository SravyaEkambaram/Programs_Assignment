﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureDealer
{
    class Program
    {
        public static List<Model> mlist = new List<Model>();
        mlist.Add("4 seater");
        mlist.Add("6 seater");
        mlist.Add("8 seater");
        public string name;
       public readonly int FurnitureCode;
       public int noOfModels=3;
       public string Category;
        public void Furniture_Details()
        {
            Console.WriteLine("Enter the name of furniture");
            name = Console.ReadLine();
            Console.WriteLine("Enter the furniture category");            
            Category= Console.ReadLine();
        }
      






        static void Main(string[] args)
        {
        }
    }
}
