﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Furniture
{
    class Program
    {
        public static List<Model> mlist = new List<Model>();
       // List<int> fc = new List<int>();
        //fc.Add(100,101,102);
        mlist.Add(101,102,103);
    }
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Furniture dealers");
        int choice = GetInt("Enter the choice");

           displayMenu();
           Model m = new Model();
           Options(m);
        public static void displayMenu()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("1.add_model");
        Console.WriteLine("2.Edit Account");
        Console.WriteLine("3.Deposit");
        Console.WriteLine("4.Withdrawal");
        Console.WriteLine("5.Check Balance");
        Console.WriteLine("6.CloseAccount");
        Console.WriteLine("7.Amount Transactions");


        Console.ResetColor();

    }
    public static void options(Model obj)
    {
        int choice = GetInt("Enter the choice");
        switch (choice)
        {
            case 1:
                obj.add_model();
                mlist.Add(obj);
                break;
            case 2:
                obj.delete_model();
                break;
            case 3:
                obj.display_allmodels();
                break;
            case 4:
                obj.modify_price();
                break;
            case 5:
                obj.lowest_priced_model();
                break;
            case 6:
                obj.modelsIn_Aprice_range();
                break;
            case 7:
                obj.display_1model();
                break;
            case 8:
                obj.check_availability();
                break;
            default:
                Console.WriteLine("Please choose a valid option");
                break;
        }
    }
    private static int GetInt(string message)
    {
        int val = 0;
        while (true)
        {

            Console.WriteLine(message);
            if (int.TryParse(Console.ReadLine(), out val))
                break;
            
            Console.WriteLine("The entered number is not in correct format please try again");
           
        }
        return val;
    }

















}

