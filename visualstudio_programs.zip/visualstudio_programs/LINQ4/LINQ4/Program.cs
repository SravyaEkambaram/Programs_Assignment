﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 3, 4, 2, 6, 7, 8 };
            var lownums = from n in nums
                          where n < 5
                          select n;
            foreach(var item in lownums)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();                    
        }
    }
}
