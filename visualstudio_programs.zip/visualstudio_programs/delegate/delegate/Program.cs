﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @delegate
{
    delegate int Calculator(int n);
    class Delegate
    {
        public static volatile int number = 10;
       // static int number = 10;
        public static int Add(int n)
        {
            number += n;
            return number;
        }
        public static int Mul(int n)
        {
            number *= n;
            return number;
        }
        public static int getvalue()
        {
            return number;
        }


     public static void Main(string[] args)
        {
            Calculator c1 = new Calculator(Add);
            Calculator c2 = new Calculator(Mul);
            c1(5);
            Console.WriteLine("after c1 delegate number is" + getvalue());
            c2(3);
            Console.WriteLine("after c2 delegate number is"+ getvalue());
            Console.ReadKey();
        }
    }
}
