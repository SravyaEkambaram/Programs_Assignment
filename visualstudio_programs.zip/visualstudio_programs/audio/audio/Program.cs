﻿using System;
using System.Media;
namespace ConsoleApplication5
{
    class Sound
    {

        static void Main(string[] args)
        {
            playSimpleSound();
            Console.ReadKey();
        }
        private static void playSimpleSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\Alarm01.wav");
            simpleSound.Play();
         }
    }
 } 
    


