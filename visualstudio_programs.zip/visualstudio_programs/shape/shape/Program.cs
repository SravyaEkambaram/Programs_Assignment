﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape
{
    class shape
    {

        static void Main(string[] args)
        {
      
              Triangle T = new Triangle(20, 30);
                Rectangle R = new Rectangle(30, 40);
                T.TriArea();
                R.RecArea();               
                Console.ReadKey();
         }
     }
     class Triangle : shape
     {
            int b, h;
            public Triangle(int breadth, int height)
            {
              b = breadth ;
              h = height ;
            }
            public void TriArea()
            {
              int TArea =(b*h)/2 ;
                Console.WriteLine($"Area of Triangle is {TArea}");
            }
       }
       class Rectangle : shape
       {
            int l, b;
            public Rectangle(int length, int breadth)
            {
                l = length;
                b = breadth;
            }
            public void  RecArea()
            {
                int RArea = l * b;
                Console.WriteLine($"Area of Rectangle is {RArea}" );
            }
       }
  }