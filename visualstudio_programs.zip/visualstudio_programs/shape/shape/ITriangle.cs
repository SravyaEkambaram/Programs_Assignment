﻿namespace shape
{
    internal interface ITriangle
    {
    }
}