﻿namespace shape
{
    internal interface IRectangle
    {
    }
}