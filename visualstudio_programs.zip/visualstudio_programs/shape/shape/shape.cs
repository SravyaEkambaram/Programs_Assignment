﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape
{
    class shape
    {

        static void Main(string[] args)
        {

            Triangle T = new Triangle();
            Rectangle R = new Rectangle();
            double n1, n2;
            set(out n1, out n2);
            double TArea = T.Area(n1, n2);
            double RArea = R.Area(n1, n2);
            display(TArea, RArea);
            Console.ReadKey();

        }

        private static void display(double Tarea, double rArea)
        {
            Console.WriteLine($"Area of Triangle is: {Tarea}");
            Console.WriteLine($"Area of Rectangle is:{rArea}");
        }

        public static void set(out double n1, out double n2)
        {
            Console.WriteLine("Enter the length");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth");
            n2 = double.Parse(Console.ReadLine());
        }
    }
    class Shape2
    {

        public virtual double Area(double n1, double n2)
        {
            return 0.0;
        }

    }
    class Triangle : Shape2
    {
        double b, h;

        public override double Area(double n1, double n2)
        {
            b = n1;
            h = n2;
            double Areaoftri = ( b * h)/2;
            return Areaoftri;
        }
    }
    class Rectangle : Shape2
    {
        double l, h;
        public override double Area(double n1, double n2)
        {
            l = n1;
            h = n2;
            double AreaofRec = l * h;
            return AreaofRec;
        }
    }
}