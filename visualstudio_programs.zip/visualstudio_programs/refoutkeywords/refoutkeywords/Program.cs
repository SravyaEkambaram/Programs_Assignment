﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace refoutkeywords
{
    class Program
    {
        static void Main(string[] args)
        {
            string x = "a";
            string y = "b";
            int sum;
            Console.WriteLine($"before swap x={x} y={y}");
            swap(ref x, ref y, 9, 10, out sum);
            Console.WriteLine(sum);
            Console.WriteLine($"after swap x={x} y={y}");
            Console.ReadKey();
        }

        private static void swap(ref string x, ref string y, int v1, int v2, out int sum)
        {
            string t = x;
            x = y;
            y = t;
            sum = v1+v2;
           
        }
    }
}
