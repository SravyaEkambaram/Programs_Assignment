﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prop
{
    class Emp
    {
        
        public string Name { get; set; }
    }

    class TestEmp
    {
        static void Main(string[] args)
        {
            Emp e = new Emp();
            e.Name="sravya";
            Console.WriteLine($"Employee name:{e.Name}");
            Console.ReadKey();
        }
    }
}
