﻿using exmethod;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exmethod
{
    static class ExDemo

    {
        public static void sayhello(this Employee e)
        {
            Console.WriteLine($"{e.id} {e.name}");
        }
            public static void sayhello(this Employee e, Manager m)
        {
            Console.WriteLine($"{e.id} {e.name}");
            Console.WriteLine($"{m.id} {m.name}");
            Console.ReadKey();

        }
        public static void sayhello(this List<Employee> list)
        {
            Console.WriteLine(list[0].id);
        }
    }
    class Employee
    {
        public int id { get; set; }
        public string name { get; set; }

    }
    class Manager
    {
        public int id { get; set; }
       public string name { get; set; }

    }
    class mainclass
    {

        public static void Main(String[] args)
        {
            Employee e = new Employee {  id = 1, name = "sravya" };
            Manager m=new Manager { id = 2, name = "abc" };
            Employee e1 = new Employee { id = 3, name = "list" };
            e.sayhello(m);
            List<Employee> list = new List<Employee>();
            list.Add(e);
            list.Add(e1);
            list.sayhello();

           
        }
    }
}

