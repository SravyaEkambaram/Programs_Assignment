﻿namespace exmethod
{
    public class employee1
    {
        internal bool id;
    }
}