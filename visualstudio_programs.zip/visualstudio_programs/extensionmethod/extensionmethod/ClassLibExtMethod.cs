﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibExtMethod
{ 
    class c1
    {
        public string Display()
        {
            return ("Iam in display method");
        }
        public string Print()
        {
            return ("Iam in print method");
        }
    }
}
