﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    public class Person
    {
        string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        int age;
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }
        public class persondet
        {
            public static void Main()
            {
                Person p = new Person();
                p.Name = "abc";
                p.Age = 15;
                Console.WriteLine("name = {0} \n age = {1}", p.Name, p.Age);
                Console.ReadKey();
            }

        }
        public class Person2
        {
            private int age;
            public int AGE
            {
                get
                {
                    return age;
                }
                set{ }
                    
               
            }
            private string name;
            public string NAME
            {
                get
                {
                    return name;
                }
                set { }
            }
        }
    }
}
