﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIDlist
{
    class Program
    {

        static void Main(string[] args)
        {
            int rn,temp=0;
            List<int> list = new List<int>();
            List<int> Random= new List<int>();

            Random r = new Random();
            Console.WriteLine("Enter the number of Associate:");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the GID number:");        
            for (int i = 0; i < n; i++)
            {
                int GID = int.Parse(Console.ReadLine());
                list.Add(GID);
                
                rn = r.Next(1, 40);
                list.Add(rn);
                
            }

           /* for (int i = 0; i < n; i++)
            {
                rn = r.Next(1,40);
                Random.Add(rn);
                temp = rn;
            }
            Random.ForEach(Console.WriteLine);*/

           
            
            Console.WriteLine($"The Associate number ");
            Console.WriteLine($"Corresponding system number ");
            list.ForEach(Console.WriteLine);
            Console.ReadKey();
        }
    }
}