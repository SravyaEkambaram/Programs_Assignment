﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GID
{
    class Program
    {
        static void Main(string[] args)
        {
            int GID;
            Console.WriteLine("Enter the GID:");
            int.TryParse(Console.ReadLine(),out GID);

            Random r = new Random();
            int n =  r.Next(0,40);
            
            Console.WriteLine($"The System for the {GID} is {n}");
            Console.ReadKey();
        }
    }
}
