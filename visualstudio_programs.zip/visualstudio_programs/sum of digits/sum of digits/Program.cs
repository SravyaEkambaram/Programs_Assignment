﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_of_digits
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            int number = int.Parse(Console.ReadLine());
            int sum = 0;
            int digit;
            int temp;
            temp = number;
            while (number > 0)
            {
                 digit = number % 10;
                sum = sum + digit;
                number = number / 10;
            }
            Console.WriteLine($"sum of digits of {temp} is {sum}");
            Console.ReadLine();

        }
    }
}
