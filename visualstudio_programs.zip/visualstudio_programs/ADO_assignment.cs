﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ADO_assignment
{
    class Program
    {

        static string conString = @"Server=INCHCMPC09350;Database=NorthWind;Trusted_Connection=True;";
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("--BEFORE MODIFICATION---");

                DisplayData();

                InsertData();
                Console.WriteLine("---AFTER MODIFICATION---");
                DisplayData();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string insertString = @"INSERT INTO Employees(FirstName,LastName) VALUES('John', 'Rambo')";
                using (SqlCommand cmd = new SqlCommand(insertString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
        private static void DisplayData()
        {
            using (SqlConnectionStringBuilder con = new SqlConnectionStringBuilder(conString))
            {
                con.Open();
                string selectAllString = @"Select * from Employees";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"EmployeeID : {rdr[0]} | FirstName : {rdr[1]}");
                    }
                }
            }
        }
    }
}
