﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayMenu();
            int choice = GetInt("choice");
        }
        public class emp
        {

            public emp(int id, string firstname, string lastname, string email)
            {
               this.id = id;
              this.firstname = firstname;
               this.lastname = lastname;
               this.email = email;
            }

            private int id;
            public int Id
            {
                get
                {
                    return id;
                }
                set
                {
                    id = value;
                }
            }
            private string firstname;
            public string Firstname
            {
                get
                {
                    return firstname;
                }
                set
                {
                    firstname = value;
                }
            }
            private string lastname;
            public string Lastname
            {
                get
                {
                    return lastname;
                }
                set
                {
                    lastname = value;
                }
            }
            private string email;
            public string Email
            {
                get
                {
                    return email;
                }
                set
                {
                    email = value;
                }
            }
        }
        private static void DisplayMenu()
        {
            Console.WriteLine("1.Salaried employee");
            Console.WriteLine("2.contract employee");
        }
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.WriteLine("Error! Try again");
            }
            return val;
        }
    }
 }