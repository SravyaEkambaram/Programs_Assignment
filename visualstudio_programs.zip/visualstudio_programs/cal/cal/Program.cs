﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cal
{
    enum menu
    {
        Add =1,
        Sub =2,
        Mul =3,
        Div =4
    };
    class Program
    {
        static void Main(string[] args)
        {
            //display menu
            displaymenu();
            //Get users choice of operation
            int choice = GetInt("choice");
            //Get operands
            int num1 = GetInt("number 1");
            int num2 = GetInt("number 2");
            //perform operation
            int result = 0;
            switch((menu)choice)
            {
                case menu.Add: result = num1 + num2;
                        break;
                case menu.Sub:
                    result = num1 - num2;
                    break;
                case menu.Mul:
                    result = num1 * num2;
                    break;
                case menu.Div:
                    result = num1 / num2;
                    break;
            }

            //Display result
            Console.WriteLine(result);

        }
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.WriteLine("Error! Try again");
            }
            return val;
        }
        private static void displaymenu()
        {
            Console.WriteLine("1.ADD");
            Console.WriteLine("2.SUB");
            Console.WriteLine("3.MUL");
            Console.WriteLine("4.DIV");
        }

    }
}
