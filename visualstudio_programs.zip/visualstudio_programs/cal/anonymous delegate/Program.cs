﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace anonymous_delegate
{
    class Program
    {
        delegate int MyDelegate(int i, int j);
        static void Main(string[] args)
        {
            MyDelegate del = (i, j) => i + j;
            var result = del(5, 7);
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
