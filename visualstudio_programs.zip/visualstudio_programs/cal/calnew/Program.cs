﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calnew
{
    delegate int MyDelegate(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            int i = 5;
            int j = 6;
            MyDelegate del = sum;
            int result = sum(i, j);
            Console.WriteLine($"the result is {result}");
            Console.ReadKey();
        }
        public static int sum(int i, int j)
        {
            return i + j;
        }

    }
}
}
