﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            salemp e = new salemp();
            salemp c = new salemp();
            Console.ReadKey();
        }
    }
    interface iperson

    { }
    interface iprivilage
    { }
    class salemp : iperson, iprivilage
    {
        public int id;
        public string name;
        public string emailid;
    }
}
