﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MyProject
{
    class CsharpProgramming
    {
        static void Main(string[] args)
        {
            int choice;
            Console.WriteLine("Welcome to EMS");
            Console.WriteLine("ENTER THE CHOICE BELOW");
            Console.WriteLine("1. Salary Employee Service \n 2. Contract Employee Service");
            int.TryParse(Console.ReadLine(), out choice);
            switch (choice)
            {
                case 1:
                    {
                        SalaryEmployee emp1 = new SalaryEmployee();
                        emp1.getValues();
                        emp1.welcome();
                        emp1.previlage();
                        break;
                    }
                case 2:
                    {
                        ContractEmployee emp2 = new ContractEmployee();
                        emp2.getValues();
                        emp2.welcome();
                        break;
                    }
            }
            Console.ReadKey();
        }
    }
    interface IPerson
    {
        void welcome();
    }
    interface IPrevilage
    {
        void previlage();
    }
    public class Employee
    {
        public int id;
        public string Fname;
        public string LName;
        public string email;
        public void getValues()
        {
            Console.WriteLine("Enter Your id");
            int.TryParse(Console.ReadLine(), out id);
            Console.WriteLine("Enter your Fname");
            Fname = Console.ReadLine();
            Console.WriteLine("Enter your Lname");
            LName = Console.ReadLine();
            Console.WriteLine("Enter your Email");
            email = Console.ReadLine();
        }
    }
    class ContractEmployee : Employee, IPerson
    {

        public void welcome()
        {
            Console.WriteLine("Hi My Name is {0} {1}", Fname, LName);
        }
    }
    class SalaryEmployee : Employee, IPerson, IPrevilage
    {
        public void welcome()
        {
            Console.Write("Hi, My name is {0} {1}", Fname, LName);
        }
        public void previlage()
        {
            Console.WriteLine(" and is belong to the club");
        }
    }
}
