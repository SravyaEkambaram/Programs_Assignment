﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace @static
{
  public   class Account
    {
   
         
        public string name { get; set; }
        public int id { get; set; }
        public void display()
        {
            Console.WriteLine($"Employee Name {name} ID:{id}");
        }
    }
    class TestAccount
    {
        public static void Main(string[] args)
        {
            Account a1 = new Account { name = "aaa", id = 1};
            a1.display();
            
            Console.ReadKey();

        }
    }
}