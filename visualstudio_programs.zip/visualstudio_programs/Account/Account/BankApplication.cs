﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    public abstract class Account
    {
        public int AccountNumber;
        public string UserName;
        public int Balance;

        public abstract void Openaccount();
        public abstract void Closeaccount();
        public abstract void Editaccount();
        public abstract void Deposit();
        public abstract void Withdrawl();
        public abstract void CheckBalance();
    }




