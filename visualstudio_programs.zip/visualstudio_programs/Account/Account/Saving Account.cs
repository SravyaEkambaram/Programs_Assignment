﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Saving_Account:Account
    {
        public override int Openaccount()
        {
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(1, 9).ToString();
            }
            if (w.Length == 12)
            {
                Console.WriteLine(w);
            }

            Console.ReadLine();



        }
    }
}
