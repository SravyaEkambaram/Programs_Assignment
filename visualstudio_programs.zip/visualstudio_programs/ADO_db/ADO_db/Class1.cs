﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
//using System.Speech.Synthesis;


namespace ADO.net1
    {
        class Program
        {

            //  static string conString = @"Server=INCHCMPC11363;Database=assignmentDatabase;Trusted_Connection=True;";
            static void Main(string[] args)
            {
                StringBuilder sb = new StringBuilder(@"Server=");
                Console.WriteLine("Please enter the server name");
                sb.Append(Console.ReadLine());
                sb.Append(";Database=");
                Console.WriteLine("Please enter the database name");
                sb.Append(Console.ReadLine());
                sb.Append(";Trusted_Connection=True;");
                Console.WriteLine(sb);
                try
                {
                    //SpeechSynthesizer speaker = new SpeechSynthesizer();
                    //speaker.Speak("Before inserting the data");
                    Console.WriteLine("*****Before inserting the data*****");
                     DisplayData(sb);

                    // InsertData(sb);
                    //speaker.Speak("After inserting the data");
                Console.WriteLine("******After inserting the data in to the sectors*****");
                  //  Display(sb);
                   // DeleteData(sb);
                   // speaker.Speak("After deleting  the data");
                    //Display(sb);
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
            Console.ReadLine();
        }

         /*   private static void DeleteData(StringBuilder sb)
            {
                Console.WriteLine("Please enter the tablename and condition for the deletion operation");
                StringBuilder s = new StringBuilder(@"DELETE FROM  ");
                s.Append(Console.ReadLine());
                s.Append("where sector_id = ");
                s.Append(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine(s);

                //string stringg = @"Delete from sectors where sector_id = 11";
                using (SqlConnection con = new SqlConnection(sb.ToString()))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(s.ToString(), con))
                    {
                        cmd.ExecuteNonQuery();
                    }

                }
            }*/

          /*  private static void InsertData(StringBuilder sb)
            {
                Console.WriteLine("Please enter the data to be inserted");
                string insertdatstring = @"Insert into sectors values('" + Console.ReadLine() + "')";
                Console.WriteLine(insertdatstring);
                using (SqlConnection con = new SqlConnection(sb.ToString()))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(insertdatstring, con))
                    {
                        cmd.ExecuteNonQuery();
                    }

                }
            }*/

        private static void DisplayData(StringBuilder sb)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sb.ToString()))
                {
                    Console.WriteLine("Please enter the table to be selected");
                    string cmdString = @"SELECT * FROM  " + Console.ReadLine() ;
                    using (SqlCommand cmd = new SqlCommand(cmdString, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        DataRow[] dra = new DataRow[dt.Rows.Count];
                        
                        da.Fill(ds);

                        foreach (DataColumn dr in ds.Tables[0].Columns)
                        {
                            Console.WriteLine("column names");
                            Console.WriteLine("{0,15}", dr.ColumnName);
                        }
                        Console.WriteLine("CONTENT");
                        for (int i = 0; i < dra.Length; i++)
                        {
                            if (dt.Rows.Count > 0)
                            {
                                string s = 
                            }
                        }



                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception thrown while displaying data: {ex.Message}");
            }

        }
    }
}