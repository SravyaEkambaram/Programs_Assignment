﻿namespace extensionmethod1
{
    internal class Class1
    {
        public Class1()
        {
        }
    }
}