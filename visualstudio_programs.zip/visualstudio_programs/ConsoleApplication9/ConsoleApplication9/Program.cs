﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
   delegate int MyDelegate(int i, int j);
    class Program
    {
      
        static void Main(string[] args)
        {
            int i = 5;
            int j = 6;
          MyDelegate del = sum;
            del += sub;
            int result = sum(i, j);
            int result2 = sub(i, j);
            Console.WriteLine($"the add is {result} \nand sub is { result2}");
            Console.ReadKey();
        }
        public static int sum(int i,int j)
        {
            return i + j;
        }
        public static int sub(int i, int j)
        {
            return i - j;
        }
    }
}
