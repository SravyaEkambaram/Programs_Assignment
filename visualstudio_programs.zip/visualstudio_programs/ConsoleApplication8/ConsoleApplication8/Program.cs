﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    public class CoOrds
    {
        public int x, y;

        // Default constructor:
        public CoOrds()
        {
            x = 12;
            y = 0;
            //Console.WriteLine(x,y);
        }

     }
    class Mainclass
    {
        public static void Main()
        {
            CoOrds p1 = new CoOrds();
           
            Console.WriteLine( p1.x + p1.y);
            Console.ReadKey();
        }
    }
}
