﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 10;
            int f1 = 0;
            int f2 = 1;
            int next;
            for(int c=0;c<n;c++)
            {
                if(c<=1)
                {
                    next = c;
                }
                else
                {
                    next = f1+f2;
                    f1 = f2;
                    f2 = next;
                }
                Console.WriteLine($"fibonacci series of first 10 numbers is {next}");
              
            }
            Console.ReadKey();
        }
    }
}
