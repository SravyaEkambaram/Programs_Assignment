﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication10
{
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        List<int> MYList = new List<int>();
    //        List<string> Name = new List<string>();
    //        MYList.Add(45);
    //        MYList.Add(54);
    //        MYList.Add(78);
    //        MYList.Add(23);
    //        Name.Add("Madhu");
    //        Name.Add("Tamil");
    //        Name.Add("Sravs");
    //        Name.Add("Jenny");


    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("<table>");
    //        foreach (var item in MYList)
    //        {
    //            foreach (var nam in Name)
    //            {
    //                sb.AppendFormat("<tr><td>{0}</td></tr>", item);
    //                Console.WriteLine(item);
    //                Console.WriteLine(nam);
    //            }
    //        }
    //        sb.Append("</table>");
    //        Console.ReadKey();
    //    }
    //}
   
    public class Listobj
{
    public int Age { get; set; }
    public string Name { get; set; }

    public override string ToString()
    {
        return string.Format("My name is {0} and I'm {1} years old.", Name, Age;
    }
}
}
