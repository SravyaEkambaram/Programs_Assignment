﻿namespace WindowsFormsApplication1
{
    public class Form
    {
    }
}