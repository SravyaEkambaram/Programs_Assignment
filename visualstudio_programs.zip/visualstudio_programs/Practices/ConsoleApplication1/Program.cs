﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            public int Age { get; set; }
            public string Name { get; set; }

            public override string ToString()
            {
                return string.Format("My name is {0} and I'm {1} years old.", Name, Age);
            }
        }
    }
}
