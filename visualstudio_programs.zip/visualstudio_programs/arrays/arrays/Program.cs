﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // char[] vowels = new char[5];
            // vowels[0] = 'a';
            /// vowels[1] = 'e';
            // vowels[2] = 'i';
            // vowels[3] = 'o';
            // vowels[4] = 'u';

            //  char[] vowels =  { 'a', 'e', 'i', 'o', 'u' };
           
           
            int[][] matrix = new int[][]
            {
               new int[] {0,1,2},
               new int[] {3,4,5},
               new int[] {6,7,8}
            };
            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[3]; // Create inner array
                for (int j = 0; j < matrix[i].Length; j++)
                    matrix[i][j] = i * 3 + j;
            }
            Console.WriteLine(matrix[2][2]);
            //  Console.WriteLine(vowels[2]);
            Console.ReadLine();
        }
    }
}
