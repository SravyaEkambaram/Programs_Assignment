﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nullable
{
    class Program
    {
        static void Main(string[] args)
        {
            int? i = null;
            int? j = 2;
            int? k = 3;
            bool? boolval = new bool?();
            Console.WriteLine($"{i} {j} {boolval}");
           int x = i ?? 2;            
            Console.WriteLine($"{x}");
            x = k ?? 2;
            Console.WriteLine($"{x}");
            Console.ReadKey();
        }
    }
}
