﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i,j;
            int num;
            Console.WriteLine("enter array size:");
            int[] a = new int[10];
            int.TryParse(Console.ReadLine(), out num);
            double average, sum = 0;
            Console.WriteLine("Enter array elements: ");
             for (i = 0; i < num; i++)
            {
                a[i] =int.Parse(Console.ReadLine());
            }
            /*  Compute the sum of all elements */
            for (j = 0; j < num; j++)
            {
                sum = sum + a[j];
            }
            average = sum / num;
            Console.WriteLine($"mean is {average}");
           // median


            float midvalue = 0;

            if (num % 2 == 0)

            {
                int var = ((num) / 2) - 1;
                for (i = 0; i < num; i++)
                {
                    if (var == 1 || (var + 1) == i)
                    {
                        midvalue = midvalue + a[i];
                    }
                }

                midvalue = midvalue / 2;
                Console.WriteLine("The median value is {0}", midvalue);
            }
            else
            {
                int var = (num) / 2;
                for (i = 0; i < num; i++)
                {
                    if (var == i)

                    {

                        midvalue = a[i];

                        Console.WriteLine("The median value is{0}", midvalue);
                    }
                }
            }
            Console.ReadKey();
            //mode
            int[] x = new int[] { 1, 2, 1, 2, 4, 3, 2 };

            Dictionary<int, int> counts = new Dictionary<int, int>();
            foreach (int a1 in x)
            {
                if (counts.ContainsKey(a1))
                    counts[a1] = counts[a1] + 1;
                else
                    counts[a1] = 1;
            }

            int result = int.MinValue;
            int max = int.MinValue;
            foreach (int key in counts.Keys)
            {
                if (counts[key] > max)
                {
                    max = counts[key];
                    result = key;
                }
            }

            Console.WriteLine("The mode is: " + result);
            Console.ReadKey();

            //  Computing variance  and standard deviation  
            for (i = 0; i < num; i++)
            {
               sum = sum+ Math.Pow((a[i] - average), 2);
            }
            double variance = sum / (float)num;
            double std_deviation = Math.Sqrt(variance);         
            Console.WriteLine($"variance of all elements is {variance}" );
            Console.WriteLine($"Standard deviation is{std_deviation}");
            Console.ReadKey();
        }   
    }
}

