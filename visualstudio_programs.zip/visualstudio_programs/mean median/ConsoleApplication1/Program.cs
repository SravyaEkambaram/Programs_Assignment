﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i,j;
            int num;
            Console.WriteLine("enter array size:");
            int[] a = new int[10];
            int.TryParse(Console.ReadLine(), out num);
            double average, sum = 0;
            Console.WriteLine("Enter array elements: ");
             for (i = 0; i < num; i++)
            {
                a[i] =int.Parse(Console.ReadLine());
            }
            /*  Compute the sum of all elements */
            for (j = 0; j < num; j++)
            {
                sum = sum + a[j];
            }
            average = sum / num;
            Console.WriteLine($"mean is {average}");
          
            //  Computing variance  and standard deviation  
            for (i = 0; i < num; i++)
            {
               sum = sum+ Math.Pow((a[i] - average), 2);
            }
            double variance = sum / (float)num;
            double std_deviation = Math.Sqrt(variance);         
            Console.WriteLine($"variance of all elements is {variance}" );
            Console.WriteLine($"Standard deviation is{std_deviation}");
            Console.ReadKey();
        }   
    }
}

