﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mean_median
{
    class Program
    {
        static void Main(string[] args)
        {
            int i ;
            int num;
            int[] a = new int[10];
            int.TryParse(Console.ReadLine(), out num);
            float average, sum = 0;  
            Console.WriteLine("Enter %d real numbers ");
           // for (i = 0; i < num; i++)
            //{
              //  Console.WriteLine(a[i]);
            //}
            /*  Compute the sum of all elements */
            for (i = 0; i < num; i++)
            {
                sum = sum + a[i];
            }
             average = sum / num;
            Console.WriteLine($"mean is {average}");
            Console.ReadKey();
        }
    }
}
