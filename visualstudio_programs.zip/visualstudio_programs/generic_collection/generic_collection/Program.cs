﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generic_collection
{
    class Program
    {
        static void Main(string[] args)
        {
            collection<int> numbers = new collection<int>();
            numbers.Add(2);
            numbers.Add(3);

        }
    }
}
