﻿namespace generic_collection
{
    internal class collection<T>
    {
    }
}