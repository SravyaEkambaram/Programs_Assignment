﻿using parameterizedconst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parameterizedconst
{
    class Employee
    {
        public int id;
        public string name;
        public Employee(int i, string n)
        {
            id = i;
            name = n;
        }
        public void display()
        {
            Console.WriteLine($"id:{id} name:{name}");
        }

    }

        class TestEmployee
        { 
            static void Main(string[] args)
            {
                Employee e1 = new Employee( 1,  "sravs");
                Employee e2 = new Employee(2, "karan");
                e1.display();
                e2.display();
                Console.ReadKey();
            }
       }
}