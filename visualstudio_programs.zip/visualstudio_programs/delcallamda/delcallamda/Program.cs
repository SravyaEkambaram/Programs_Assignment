﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delcallamda
{
    

    
        enum menu
        {
            Add = 1,
            Sub = 2,
            Mul = 3,
            Div = 4
        };

        delegate int MyDelegate(int num1, int num2);

        class Program
        {
            static void Main(string[] args)
            { //display menu
                displaymenu();
                //delegate
                MyDelegate del+ =(num1,num2)=>num1+num2;
                del = (num1, num2) => num1 - num2;
                del = (num1, num2) => num1 * num2;
            del = (num1, num2) => num1 / num2;
            //Get users choice of operation
            int choice = GetInt("choice");
                //Get operands
                int num1 = GetInt("number 1");
                int num2 = GetInt("number 2");

                //perform operation
                int result = 0;
                switch ((menu)choice)
                {
                    case menu.Add:
                        result = del(num1, num2);
                        break;
                    case menu.Sub:
                        result = del(num1, num2);
                        break;
                    case menu.Mul:
                        result = del(num1, num2);
                        break;
                    case menu.Div:
                        result = del(num1, num2);
                        break;
                }

                //Display result
                Console.WriteLine(result);
                Console.ReadKey();

            }
            private static int GetInt(string message)
            {
                int val = 0;
                while (true)
                {
                    Console.WriteLine(message);
                    if (int.TryParse(Console.ReadLine(), out val))
                        break;
                    Console.WriteLine("Error! Try again");
                }
                return val;
            }
            //public static int Add(int num1, int num2)
            //{
            //    return num1 + num2;
            //}
            //public static int Sub(int num1, int num2)
            //{
            //    return num1 - num2;
            //}
            //public static int Mul(int num1, int num2)
            //{
            //    return num1 * num2;
            //}
            //public static int Div(int num1, int num2)
            //{
            //    return num1 / num2;
            //}

            private static void displaymenu()
            {
                Console.WriteLine("1.ADD");
                Console.WriteLine("2.SUB");
                Console.WriteLine("3.MUL");
                Console.WriteLine("4.DIV");


            }
        }
    }
